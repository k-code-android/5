package com.example.mydraganddrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipDescription;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener, View.OnDragListener {

    private android.widget.RelativeLayout.LayoutParams layoutParams;
    private LinearLayout dragBackGround;
    private ImageView dragImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dragBackGround = (LinearLayout) findViewById(R.id.whitelayout);
        dragImg = (ImageView)  findViewById(R.id.imgView);
        dragImg.setTag("I am draggable");
        dragImg.setOnTouchListener(this);
        dragBackGround.setOnDragListener(this);
    }

    @Override
    public boolean onDrag(View v, DragEvent dragEvent) {
        switch (dragEvent.getAction()) {
            case DragEvent.ACTION_DRAG_ENDED:
                return true;
            case DragEvent.ACTION_DRAG_EXITED:

                return true;
            case DragEvent.ACTION_DRAG_ENTERED:

                return true;
            case DragEvent.ACTION_DRAG_STARTED:

                    return true;

            case DragEvent.ACTION_DROP:
                // Gets the data item containing the dragged data
                ClipData.Item item = dragEvent.getClipData().getItemAt(0);
                // Gets the text data from the data item.
                String dragData = item.getText().toString();
                // Displays a message containing the dragged data.
                Toast.makeText(this, "Dragged data is " + dragData, Toast.LENGTH_SHORT).show();
                View tvState = (View) dragEvent.getLocalState();
                ViewGroup tvParent =(ViewGroup) tvState.getParent();
                tvParent.removeView(tvState);
                tvState.setX(dragEvent.getX()-(tvState.getWidth()/2));
                tvState.setY(dragEvent.getY()-(tvState.getHeight()/2));
                tvState.setVisibility(View.VISIBLE);
                ((LinearLayout) v).addView(tvState);
                v.setVisibility(View.VISIBLE);
                return true;
            case DragEvent.ACTION_DRAG_LOCATION:

                return true;
            default:
                return false;
        }

    }

    @Override
    public boolean onTouch(View v, MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
            ClipData.Item item = new ClipData.Item((CharSequence) v.getTag());
            // Create a new ClipData using the tag as a label, the plain text MIME type, and
            // the already-created item. This will create a new ClipDescription object within the
            // ClipData, and set its MIME type entry to "text/plain"
            String[] mimeTypes = {ClipDescription.MIMETYPE_TEXT_PLAIN};
            ClipData data = new ClipData(v.getTag().toString(), mimeTypes, item);
            View.DragShadowBuilder dragShadow = new View.DragShadowBuilder(v);
            v.startDrag(data, dragShadow, v, 0);
            v.setVisibility(View.INVISIBLE);
            return true;
        } else {
            return false;
        }

    }
}


